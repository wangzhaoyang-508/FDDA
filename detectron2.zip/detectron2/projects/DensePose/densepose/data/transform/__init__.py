# Copyright (c) Facebook, Inc. and its affiliates.

# pyre-unsafe

from .image import ImageResizeTransform
