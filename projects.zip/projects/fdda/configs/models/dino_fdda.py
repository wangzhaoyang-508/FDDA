from detrex.config import get_config
from detrex.modeling import ModifiedMatcher, FocalLossCost, L1Cost, GIoUCost
from detrex.modeling.backbones.tepg import TEPG
from detrex.modeling.backbones.tdcs import TDCS
from ..models import DINOTransformerFDDA
from ..models import DINOFDDA
from detrex.modeling.criterion.fdda_criterion import FDDACriterion

cfg = get_config()

# 模型配置
cfg.model = DINOFDDA(
    backbone=dict(
        type="ResNet",
        depth=50,
        num_stages=4,
        out_indices=(1, 2, 3),
        frozen_stages=1,
        norm="FrozenBN",
    ),
    position_embedding=dict(
        type="SinePositionalEncoding",
        num_feats=128,
        normalize=True,
    ),
    transformer=dict(
        type="DINOTransformerFDDA",
        # FDDA模块
        tegp_module=TEPG(
            feature_dim=256,
            domain_prompt_dim=256,
            num_domains=2,
        ),
        tdcs_module=TDCS(
            hidden_dim=256,
            num_layers=6,
        ),
        # 原有DINO参数
        num_feature_levels=4,
        two_stage_num_proposals=900,
        encoder=dict(
            type="DINOTransformerEncoder",
            num_layers=6,
            transformerlayers=dict(
                attn=dict(
                    type="MultiScaleDeformableAttention",
                    embed_dim=256,
                    num_heads=8,
                    dropout=0.1,
                    batch_first=True,
                    num_levels=4,
                ),
                ffn=dict(
                    type="FFN",
                    embed_dim=256,
                    feedforward_dim=1024,
                    output_dim=256,
                    ffn_drop=0.1,
                ),
            ),
        ),
        decoder=dict(
            type="DINOTransformerDecoder",
            num_layers=6,
            return_intermediate=True,
            transformerlayers=dict(
                attn=dict(
                    type="MultiheadAttention",
                    embed_dim=256,
                    num_heads=8,
                    attn_drop=0.1,
                    batch_first=True,
                ),
                ffn=dict(
                    type="FFN",
                    embed_dim=256,
                    feedforward_dim=1024,
                    output_dim=256,
                    ffn_drop=0.1,
                ),
            ),
        ),
    ),
    embed_dim=256,
    num_classes=80,
    num_queries=900,
    criterion=dict(
        type="FDDACriterion",
        num_classes=80,
        matcher=dict(
            type="ModifiedMatcher",
            cost_class=dict(
                type="FocalLossCost",
                alpha=0.25,
                gamma=2.0,
                weight=2.0,
            ),
            cost_bbox=dict(type="L1Cost", weight=5.0),
            cost_giou=dict(type="GIoUCost", weight=2.0),
        ),
        weight_dict=dict(
            loss_class=1.0,
            loss_bbox=5.0,
            loss_giou=2.0,
            loss_encoder_alignment=1.0,
            loss_encoder_discriminant=1.0,
            loss_decoder_alignment=1.0,
            loss_decoder_discriminant=1.0,
        ),
        alpha=1.0,
        beta=1.0,
    ),
    pixel_mean=[123.675, 116.280, 103.530],
    pixel_std=[58.395, 57.120, 57.375],
    device="cuda",
)

# 训练配置
cfg.train = get_config()
cfg.train.init_checkpoint = ""
cfg.train.output_dir = "./output/dino_fdda"
cfg.train.max_iter = 90000
cfg.train.eval_period = 5000
cfg.train.checkpointer = dict(period=5000, max_to_keep=10)

# 优化器
cfg.optimizer = get_config()
cfg.optimizer.lr = 1e-4
cfg.optimizer.weight_decay = 1e-4

# 数据加载器
cfg.dataloader = get_config()
cfg.dataloader.train = get_config()
cfg.dataloader.train.batch_size = 16
cfg.dataloader.train.num_workers = 8