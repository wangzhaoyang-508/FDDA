import torch
import torch.nn as nn
from typing import Dict, List, Optional
from detrex.modeling import DINO, DINOTransformer


class DINOFDDA(DINO):
    """
    DINO with FDDA modules for feature disentanglement
    """

    def __init__(
            self,
            *args,
            # FDDA参数
            tegp_module: Optional[nn.Module] = None,
            tdcs_module: Optional[nn.Module] = None,
            **kwargs
    ):
        super().__init__(*args, **kwargs)

        # 替换Transformer为FDDA版本
        if hasattr(self, 'transformer') and isinstance(self.transformer, DINOTransformer):
            self.transformer = DINOTransformerFDDA(
                encoder=self.transformer.encoder,
                decoder=self.transformer.decoder,
                num_feature_levels=self.transformer.num_feature_levels,
                two_stage_num_proposals=self.transformer.two_stage_num_proposals,
                learnt_init_query=self.transformer.learnt_init_query,
                tegp_module=tegp_module,
                tdcs_module=tdcs_module,
            )

    def forward(
            self,
            batched_inputs: List[Dict[str, torch.Tensor]],
            # FDDA新增参数
            domain_labels: Optional[torch.Tensor] = None
    ):
        """
        Args:
            batched_inputs: List of input dictionaries
            domain_labels: Domain labels for FDDA disentanglement [batch_size]
        """
        # 获取domain labels（如果未提供）
        if domain_labels is None and 'domain_labels' in batched_inputs[0]:
            domain_labels = torch.stack([
                torch.tensor(x['domain_labels'], device=self.device)
                for x in batched_inputs
            ])

        # 原始图像预处理
        images = self.preprocess_image(batched_inputs)

        # 提取特征
        features = self.backbone(images.tensor)

        # 准备Transformer输入
        multi_level_feats = [features[f] for f in self.in_features]
        multi_level_masks = []
        multi_level_pos_embeds = []

        for i in range(len(multi_level_feats)):
            x = multi_level_feats[i]
            mask = self.mask_out_padding(
                x, images.image_sizes, images.tensor.size(-2), images.tensor.size(-1)
            )
            multi_level_masks.append(mask)
            multi_level_pos_embeds.append(self.position_embedding(mask))

        # 准备查询嵌入
        query_embed, tgt = self.query_embed.weight, self.tgt_embed.weight
        query_embed = query_embed.unsqueeze(0).repeat(len(images), 1, 1)
        tgt = tgt.unsqueeze(0).repeat(len(images), 1, 1)

        # Transformer前向传播（传入domain_labels）
        (
            inter_states,
            init_reference,
            inter_references,
            enc_state,
            enc_reference,
            disentanglement_losses,  # FDDA新增返回
        ) = self.transformer(
            multi_level_feats=multi_level_feats,
            multi_level_masks=multi_level_masks,
            multi_level_pos_embeds=multi_level_pos_embeds,
            query_embed=[tgt, query_embed],
            domain_labels=domain_labels,  # FDDA新增
        )

        # 计算分类和边界框输出
        outputs_classes = []
        outputs_coords = []

        for lvl in range(inter_states.shape[0]):
            reference = inter_references[lvl]
            output_class = self.class_embed[lvl](inter_states[lvl])
            output_coord = self.bbox_embed[lvl](inter_states[lvl])

            if reference.shape[-1] == 4:
                output_coord += inverse_sigmoid(reference)
                output_coord = output_coord.sigmoid()
            else:
                assert reference.shape[-1] == 2
                output_coord[..., :2] += inverse_sigmoid(reference)
                output_coord = output_coord.sigmoid()

            outputs_classes.append(output_class)
            outputs_coords.append(output_coord)

        outputs_class = torch.stack(outputs_classes)
        outputs_coord = torch.stack(outputs_coords)

        # 准备输出
        output = {
            "pred_logits": outputs_class[-1],
            "pred_boxes": outputs_coord[-1],
            "disentanglement_losses": disentanglement_losses,  # FDDA新增
        }

        if self.aux_loss:
            output["aux_outputs"] = self._set_aux_loss(outputs_class, outputs_coord)

        return output